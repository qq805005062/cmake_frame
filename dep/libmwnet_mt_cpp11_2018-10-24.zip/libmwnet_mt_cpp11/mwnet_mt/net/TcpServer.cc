// Use of this source code is governed by a BSD-style license
// that can be found in the License file.

#include <mwnet_mt/net/TcpServer.h>

#include <mwnet_mt/base/Logging.h>
#include <mwnet_mt/net/Acceptor.h>
#include <mwnet_mt/net/EventLoop.h>
#include <mwnet_mt/net/EventLoopThreadPool.h>
#include <mwnet_mt/net/SocketsOps.h>

#include <stdio.h>  // snprintf

using namespace mwnet_mt;
using namespace mwnet_mt::net;

TcpServer::TcpServer(EventLoop* loop, 
						const string& nameArg, 
						const InetAddress& listenAddr, 
						Option option, 
						size_t nDefRecvBuf, 
						size_t nMaxRecvBuf, 
						size_t nMaxSendQue)
  : m_loop(CHECK_NOTNULL(loop)),
    m_strIpPort(listenAddr.toIpPort()),
    m_strName(nameArg),
    m_acceptor(new Acceptor(loop, listenAddr, option == kReusePort)),
    m_threadPool(new EventLoopThreadPool(loop, nameArg)),
    m_connectionCallback(defaultConnectionCallback),
    m_messageCallback(defaultMessageCallback),
	m_nDefRecvBuf(nDefRecvBuf),
	m_nMaxRecvBuf(nMaxRecvBuf),
	m_nMaxSendQue(nMaxSendQue)
{
	//m_nNextSockId.getAndSet(0);
	m_nNextSockId = 1;
	m_acceptor->setNewConnectionCallback(std::bind(&TcpServer::newConnection, this, _1, _2));
}

TcpServer::~TcpServer()
{
  m_loop->assertInLoopThread();
  //LOG_TRACE << "TcpServer::~TcpServer [" << name_ << "] destructing";

  for (ConnectionMap::iterator it(m_mapConnections.begin()); it != m_mapConnections.end(); ++it)
  {
    TcpConnectionPtr conn(it->second);
    it->second.reset();
    conn->getLoop()->runInLoop(std::bind(&TcpConnection::connectDestroyed, conn));
    conn.reset();
  }
}

void TcpServer::setThreadNum(int numThreads)
{
	numThreads<=0?numThreads=1:1;
	m_nThreadNum = numThreads;
	m_threadPool->setThreadNum(m_nThreadNum); 
}

void TcpServer::start()
{
  if (m_AtomicIntStarted.getAndSet(1) == 0)
  {
    m_threadPool->start(m_threadInitCallback);

    assert(!m_acceptor->listenning());
    m_loop->runInLoop(std::bind(&Acceptor::listen, get_pointer(m_acceptor)));
  }
}

void TcpServer::newConnection(int sockfd, const InetAddress& peerAddr)
{
  m_loop->assertInLoopThread();
  EventLoop* ioLoop = m_threadPool->getNextLoop();
  InetAddress localAddr(sockets::getLocalAddr(sockfd));
  //boost::uuids::random_generator gen;
  // FIXME poll with zero timeout to double confirm the new connection
  // FIXME use make_shared if necessary
  //int64_t nSockId = m_nNextSockId.incrementAndGet();
  TcpConnectionPtr conn(new TcpConnection(ioLoop,sockfd,localAddr,peerAddr,m_nDefRecvBuf,m_nMaxRecvBuf,m_nMaxSendQue));
  conn->setSockId(m_nNextSockId);
  m_mapConnections[m_nNextSockId++] = conn;
  //conn->setSockId(nSockId);
  //m_mapConnections[nSockId] = conn;
  conn->setConnectionCallback(m_connectionCallback);
  conn->setMessageCallback(m_messageCallback);
  conn->setWriteCompleteCallback(m_writeCompleteCallback);
  conn->setCloseCallback(std::bind(&TcpServer::removeConnection, this, _1)); // FIXME: unsafe
  ioLoop->runInLoop(std::bind(&TcpConnection::connectEstablished, conn));
}

void TcpServer::removeConnection(const TcpConnectionPtr& conn)
{
  // FIXME: unsafe
  m_loop->runInLoop(std::bind(&TcpServer::removeConnectionInLoop, this, conn));
}

void TcpServer::removeConnectionInLoop(const TcpConnectionPtr& conn)
{
  m_loop->assertInLoopThread();
  size_t n = m_mapConnections.erase(conn->getSockId());
  (void)n;
  assert(n == 1);
  EventLoop* ioLoop = conn->getLoop();
  ioLoop->queueInLoop(std::bind(&TcpConnection::connectDestroyed, conn));
}

