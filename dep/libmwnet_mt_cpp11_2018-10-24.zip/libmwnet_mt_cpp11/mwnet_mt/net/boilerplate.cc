// Use of this source code is governed by a BSD-style license
// that can be found in the License file.

#include <mwnet_mt/net/BoilerPlate.h>

using namespace mwnet_mt;
using namespace mwnet_mt::net;


