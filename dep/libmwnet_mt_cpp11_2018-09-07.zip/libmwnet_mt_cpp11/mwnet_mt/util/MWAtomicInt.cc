#include "MWAtomicInt.h"
using namespace MWATOMICINT;
